﻿using Lab4SOAP.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Lab4SOAP
{
    [TestClass]
    public class CelsiusToFarenheitTest
    {
        [DataTestMethod]
        [XMLDataSource(@"DataProviders\CelsiusToFarenheitDataProvider.xml")]
        public void TestCelsiusToFarenheit(string endpointName, string celsius, string expectedResult)
        {
            //arrange
            var client = SOAPClientFactory.CreateClient();

            //act
            string actualResult = client.CelsiusToFahrenheit(celsius);

            //assert
            Assert.AreEqual(expectedResult, actualResult);
        }
    }
}
