﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;

namespace Lab4SOAP.Utils
{

    class XMLDataSourceAttribute : Attribute, ITestDataSource
    {
        IList<IDictionary<string, string>> data;

        public XMLDataSourceAttribute(string sourcePath)
        {
            XmlDocument doc = new XmlDocument();
            var assemblyName = Assembly.GetExecutingAssembly().GetName().Name;
            var projectDir = new DirectoryInfo(Path.Combine(
                Environment.CurrentDirectory,
                $"..\\..\\..\\{assemblyName}\\"));
            doc.LoadXml(File.ReadAllText(Path.Combine(projectDir.FullName, sourcePath)));
            
            var nodes = doc.DocumentElement.SelectNodes("/Rows/Row");
            data = new List<IDictionary<string, string>>();

            foreach (XmlNode node in nodes)
            {
                var row = new Dictionary<string, string>();
                foreach(XmlAttribute attribute in node.Attributes)
                {
                    row.Add(attribute.Name, attribute.Value);
                }
                data.Add(row);
            }
        }

        public IEnumerable<object[]> GetData(MethodInfo methodInfo)
        {
            var parameterNames = new List<string>();
            foreach(ParameterInfo info in methodInfo.GetParameters())
            {
                parameterNames.Add(info.Name);
            }

            foreach (var row in data)
            {
                var parameters = row
                    .Where(kayVal => parameterNames.Contains(kayVal.Key))
                    .Select(kayVal => kayVal.Value as object).ToArray();
                yield return parameters;
            }
        }

        public string GetDisplayName(MethodInfo methodInfo, object[] data)
        {
            if (data != null)
                return string.Format(CultureInfo.CurrentCulture, "XMLDataSource - {0} ({1})", methodInfo.Name, string.Join(",", data));

            return null;
        }
    }
}
